//
//  ViewController.swift
//  MyFirstVieWController
//
//  Created by Ethan Sebag on 22/11/2021.
//

import UIKit

class ViewController: UIViewController , UITableViewDataSource {
    
    var todolist = [Todolist]()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return todolist.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cellContent", for: indexPath) as! TableViewCell
        let row = indexPath.row
        cell.title.text = todolist[row].getTitle()
       
        
        return cell
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "details" {
            let detailsViewController = segue.destination as! ViewController2
            let myIndexPath = tableview.indexPathForSelectedRow!
            let row = myIndexPath.row
            detailsViewController.todolist = todolist[row]
        }
    }

    
    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        todolist = [Todolist(title: "test1", desc: "testdesc1") ,Todolist(title: "test2", desc: "testdesc2"),Todolist(title: "test3", desc: "testdesc3") ,Todolist(title: "test4", desc: "testdesc4") ,Todolist(title: "test5", desc: "testdesc5")  ]
        
        tableview.dataSource = self
    }
    
   

    



}

