//
//  ViewController.swift
//  MyFirstVieWController
//
//  Created by Ethan Sebag on 22/11/2021.
//

import UIKit

class ViewController: UIViewController , UITableViewDataSource {
    
    var todolist = [Todolist]()
    

    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return todolist.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cellContent", for: indexPath) as! TableViewCell
        let row = indexPath.row
        cell.title.text = todolist[row].getTitle()
        cell.check_button.tag = row
       
        
        return cell
    }
   
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if let controller = segue.destination as? ViewController2{
                let selectedRow = tableview.indexPathForSelectedRow!.row
                controller.todolist_detail = todolist[selectedRow]
            }
        }

    
    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        for i in 1...30 {
            todolist.append(Todolist(title: "buy_milk" + String(i), desc: "description" + String(i) , state: "Not Done"))
        }
        tableview.dataSource = self
    }
    
    @IBAction func change_state(_ sender: UIButton) {
        let row = sender.tag
        todolist[row].changeState()
        todolist.remove(at: row)
        tableview.reloadData()
        
       
    }
    
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Find the row of the cell
            let row = indexPath.row
            todolist.remove(at: row)
            tableview.reloadData()
        }
    }
    
    
    
    
    
    @IBAction func unwindToMainView(_ unwindSegue: UIStoryboardSegue) {
            let addViewController = unwindSegue.source as! AddTodoViewController
            if unwindSegue.identifier == "cancel" {
                addViewController.dismiss(animated: true, completion: nil)
            }
            if unwindSegue.identifier == "save" {
                if let myTitle = addViewController.title_field.text, let myDescription = addViewController.description_field.text {
                    let new_todo = Todolist(title: myTitle, desc: myDescription , state: "Not Done")
                    todolist.append(new_todo)
                    tableview.reloadData()
                }
            }
            // Use data from the view controller which initiated the unwind segue
        }
    
   

    



}

