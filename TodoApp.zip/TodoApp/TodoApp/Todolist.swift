//
//  Todolist.swift
//  TodoApp
//
//  Created by Ethan Sebag on 03/12/2021.
//

import Foundation


class Todolist {
    var title:String
    var desc:String
    
    init(title:String, desc: String) {
        self.title = title
        self.desc = desc
    }
    
    func tostring() -> String {
        let stringaafficher = self.title + self.desc;
        return stringaafficher
    }
    
    func getTitle() -> String {
        return self.title
    }
    
    func getDesc() -> String {
        return self.desc
    }
    
}
