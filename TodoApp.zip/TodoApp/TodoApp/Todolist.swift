//
//  Todolist.swift
//  TodoApp
//
//  Created by Ethan Sebag on 03/12/2021.
//

import Foundation


class Todolist {
    var title:String
    var desc:String
    var state:String
    //var date:Date
    
    init(title:String, desc: String , state: String) {
        self.title = title
        self.desc = desc
        self.state = state
       // self.date
    }
    
    func tostring() -> String {
        let stringaafficher = self.title + self.desc;
        return stringaafficher
    }
    
    func getTitle() -> String {
        return self.title
    }
    
    func getDesc() -> String {
        return self.desc
    }
    
    func getState() -> String{
        return self.state
    }
    
    func changeState(){
        if self.state == "Done"{
            self.state = "Not Done"
        }
        else {
            self.state = "Done"
        }
    }
    
}
